﻿using HarmonyLib;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;

namespace AutoTame
{

    public class CompProperties_AutoTameTrain : CompProperties
    {
        public float radius;
        public CompProperties_AutoTameTrain()
        {
            this.compClass = typeof(CompAutoTameTrain);
        }
    }

    public class CompAutoTameTrain : ThingComp
    {
        public static HashSet<CompAutoTameTrain> comps = new HashSet<CompAutoTameTrain>();
        public CompPowerTrader compPower;
        public bool autoTame;
        public bool autoTrain;
        public string curGraphicPath;
        public CompProperties_AutoTameTrain Props => base.props as CompProperties_AutoTameTrain;
        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            compPower = this.parent.TryGetComp<CompPowerTrader>();
            comps.Add(this);
            LongEventHandler.ExecuteWhenFinished(delegate
            {
                SetGraphic();
            });
        }

        public void SetGraphic()
        {
            if (!this.compPower.PowerOn)
            {
                TryChangeGraphic(this.parent.def.graphicData.texPath + "_Off");
            }
            else if (this.autoTame)
            {
                TryChangeGraphic(this.parent.def.graphicData.texPath + "_A");
            }
            else if (this.autoTrain)
            {
                TryChangeGraphic(this.parent.def.graphicData.texPath + "_B");
            }
            else if (this.compPower.PowerOn)
            {
                TryChangeGraphic(this.parent.def.graphicData.texPath);
            }
        }
        public void TryChangeGraphic(string texPath)
        {
            if (texPath != curGraphicPath)
            {
                var graphicData = new GraphicData();
                graphicData.graphicClass = this.parent.def.graphicData.graphicClass;
                graphicData.texPath = texPath;
                graphicData.shaderType = this.parent.def.graphicData.shaderType;
                graphicData.drawSize = this.parent.def.graphicData.drawSize;
                graphicData.color = this.parent.def.graphicData.color;
                graphicData.colorTwo = this.parent.def.graphicData.colorTwo;
                var newGraphic = graphicData.GraphicColoredFor(this.parent);
                Traverse.Create(this.parent).Field("graphicInt").SetValue(newGraphic);
                if (this.parent.Spawned && base.parent.Map != null && Traverse.Create(base.parent.Map.mapDrawer).Field("sections").GetValue() != null)
                {
                    base.parent.Map.mapDrawer.MapMeshDirty(this.parent.Position, MapMeshFlag.Things);
                }
                curGraphicPath = texPath;
            }
        }

        public override void PostDeSpawn(Map map)
        {
            base.PostDeSpawn(map);
            comps.Remove(this);
        }
        public override void PostDestroy(DestroyMode mode, Map previousMap)
        {
            base.PostDestroy(mode, previousMap);
            comps.Remove(this);
        }

        public override void CompTick()
        {
            base.CompTick();
            if (autoTrain && compPower.PowerOn && Find.TickManager.TicksGame % 60000 == 0)
            {
                if (GenRadial.RadialDistinctThingsAround(this.parent.Position, this.parent.Map, Props.radius, true)
                    .OfType<Pawn>().Where(x => x.RaceProps.Animal && x.Faction == this.parent.Faction 
                    && x.training?.NextTrainableToTrain() != null)
                    .TryRandomElement(out var animal))
                {
                    var trainable = animal.training.NextTrainableToTrain();
                    animal.training.Train(trainable, null);
                }
            }
            SetGraphic();
        }

        public bool PreventsUntaming(Pawn animal)
        {
            return autoTame && compPower.PowerOn && animal.Position.DistanceTo(parent.Position) <= Props.radius;
        }
        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            if (this.parent.Faction == Faction.OfPlayer)
            {
                yield return new Command_Toggle()
                {
                    defaultLabel = "AT.AutoTame".Translate(),
                    defaultDesc = "AT.AutoTameDesc".Translate(),
                    icon = ContentFinder<Texture2D>.Get("UI/Toggleautotame"),
                    toggleAction = delegate
                    {
                        autoTame = !autoTame;
                        if (autoTame && autoTrain)
                        {
                            autoTrain = false;
                        }
                        SetGraphic();
                    },
                    isActive = () => autoTame,
                };

                yield return new Command_Toggle()
                {
                    defaultLabel = "AT.AutoTrain".Translate(),
                    defaultDesc = "AT.AutoTrainDesc".Translate(),
                    icon = ContentFinder<Texture2D>.Get("UI/Toggleautotrain"),
                    toggleAction = delegate
                    {
                        autoTrain = !autoTrain;
                        if (autoTame && autoTrain)
                        {
                            autoTame = false;
                        }
                        SetGraphic();
                    },
                    isActive = () => autoTrain,
                };
            }
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref autoTame, "autoTame");
            Scribe_Values.Look(ref autoTrain, "autoTrain");
        }
    }


    [StaticConstructorOnStartup]
    public static class Startup
    {
        static Startup()
        {
            new Harmony("AutoTame.Mod").PatchAll();
        }
        public static bool AnimalShouldNotUntame(Pawn animal)
        {
            var result = CompAutoTameTrain.comps.Any(x => x.PreventsUntaming(animal));
            return result;
        }
    }

    [HarmonyPatch(typeof(Pawn_TrainingTracker), "TrainingTrackerTickRare")]
    public class TrainingTrackerTickRare_Patch
    {
        public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator ilg)
        {
            var shouldSkip = AccessTools.Method(typeof(Startup), "AnimalShouldNotUntame");
            var pawnField = AccessTools.Field(typeof(Pawn_TrainingTracker), "pawn");
            var animalTypeField = AccessTools.Field(typeof(RaceProperties), "animalType");

            var codes = instructions.ToList();
            var label = ilg.DefineLabel();

            bool patched = false;
            for (var i = 0; i < codes.Count; i++)
            {
                var instr = codes[i];
                if (!patched && i > 5 && codes[i - 4].LoadsField(animalTypeField) && codes[i - 2].opcode == OpCodes.Bne_Un_S && codes[i - 1].opcode == OpCodes.Ret && codes[i].opcode == OpCodes.Ldarg_0)
                {
                    patched = true;
                    yield return new CodeInstruction(OpCodes.Ldarg_0).MoveLabelsFrom(instr);
                    instr.labels.Add(label);
                    yield return new CodeInstruction(OpCodes.Ldfld, pawnField);
                    yield return new CodeInstruction(OpCodes.Call, shouldSkip);
                    yield return new CodeInstruction(OpCodes.Brfalse_S, label);
                    yield return new CodeInstruction(OpCodes.Ret);
                }
                yield return instr;
            }

            if (!patched)
            {
                Log.Error("[AutoTame] Pawn_TrainingTracker:TrainingTrackerTickRare Transpiler failed");
            }
        }
    }
}
